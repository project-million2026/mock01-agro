# 1. Instalação

* Extraia o conteúdo do arquivo zip para uma pasta em seu servidor
* Execute o arquivo "setup.exe"


# 2. Atualização

* Copiar e substituir o arquivo "IP terminal.exe" na pasta de instalação (geralmente em "C:\Program Files (x86)\IP terminal")


# 3. Confguração

* Ao abrir o IP Terminal, basta inserir no campo de destino a porta que será utilizada para receber e enviar as mensagens
* Certificar que no campor "Texto Resp." esteja contido o texto "ACK" (sem aspas)
* Marcar a caixa ON para habilitar


# 4. Suporte

Em caso de dúvidas, contate a equipe de suporte via WhatsApp: +55 11 3865-0233

